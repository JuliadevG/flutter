package com.example.apppet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
